package com.daimler.s55.srv.auft.jee.p3.bcf;

import java.util.List;
import java.util.logging.Logger;

import javax.inject.Inject;

import com.daimler.s55.srv.auft.jee.p3.bs.ZCarDataBS;
import com.daimler.s55.srv.auft.jee.p3.services.ZCarInfoSI;
import com.daimler.s55.srv.auft.jee.p3.services.types.to.ZCarTO;
import com.daimler.s55.srv.tequ.jee.p3.control.api.BCF;

@BCF
public class ZcarDataBCF implements ZCarInfoSI {

    @Inject
    private ZCarDataBS zcarBs;

    @Inject
    private Logger logger;

    @Override
    public List<ZCarTO> getAllZcarData() {
        logger.info("BCF get all data called ...........");
        return zcarBs.getAllZcarData();
    }

    @Override
    public ZCarTO getZcarByFahtgestNrVersionAndStuff(ZCarTO zcarTo) {
        logger.info("logger BCF search by key called ...........");
        return zcarBs.getZcarByFahtgestNrVersionAndStuff(zcarTo);
    }

}
