package com.daimler.s55.srv.auft.jee.p3.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.daimler.s55.srv.tequ.jee.p3.persistence.api.AbstractBE;

@Entity(name = "ZCarEntity")
@Table(name = "S55RZCAR")
@NamedQueries({
        @NamedQuery(name = "ZCarEntity.fetchCarByNumber", query = "SELECT zcar from ZCarEntity zcar where zcar.zcarPk.zcarFahrgestNr=:zcarFahrgestNr AND zcar.zcarPk.zcarDokStuff=:zcarDokStuff AND zcar.zcarPk.zcarDokVersion=:zcarDokVersion"),
        @NamedQuery(name = "ZCarEntity.fetchAllZcarData", query = "SELECT zcars from ZCarEntity zcars") })
public class ZCarBE extends AbstractBE {

    @EmbeddedId
    private ZCarPK zcarPk;

    @Column(name = "ZCAR_PRODUKTION_NR", nullable = false)
    private int zcarProductionNr;

    @Column(name = "ZCAR_AUFT_NR", nullable = false, length = 10)
    private String zcarAuftNr;

    @Column(name = "ZCAR_DOK_SCHLUESSL", nullable = false, length = 27)
    private String zcarDokSchluessl;

    @Column(name = "WERK_ID", nullable = false, length = 3)
    private String werkId;

    @Column(name = "VBET_NR_ZIELLAND", nullable = false)
    private int vbetNrZielland;

    @Column(name = "ZCAR_DOK_FORMAT", nullable = false, length = 1)
    private String zcarDokFormat;

    @Column(name = "ZCAR_ZBll_ERSTELLT", nullable = false, length = 1)
    private String zcarZbllErstellt;

    @Column(name = "ZCAR_NAME_EMF_ZBll", nullable = false, length = 50)
    private String zcarNameEmfZbll;

    @Column(name = "VBET_NR_EMPF_ZBll", nullable = false)
    private int vbetNrEmpfZbll;

    @Column(name = "ZCAR_ZTPT_ERSTELLT", nullable = false, unique = true, updatable = true)
    private Date zcarZtptErstellt;

    @Column(name = "ZCAR_ZTPT_DRUCK", nullable = false, unique = true, updatable = true)
    private Date zcarZtptDruck;

    @Column(name = "ZCAR_DRUCK_WERK", nullable = false, length = 1)
    private String zcarDruckWerk;

    @Column(name = "ZCAR_ZTPT_VERSAND", nullable = false, unique = true, updatable = true)
    private Date zcarZtptVersand;

    @Column(name = "ZCAR_WLTP_REQ_ID", nullable = false, length = 50)
    private String zcarWltpReqid;

    @Column(name = "TECH_AEN_DATUM", nullable = false, unique = true, updatable = true)
    private Date techAenDatum;

    @Column(name = "TECH_AEN_USER", nullable = false, length = 8)
    private String techAenUser;

    @Column(name = "TECH_AEN_VERSION", nullable = false)
    private short techAenVersion;

    public ZCarPK getZCarPk() {
        return zcarPk;
    }

    public void setCarPk(ZCarPK zcarPk) {
        this.zcarPk = zcarPk;
    }

    public int getZcarProductionNr() {
        return zcarProductionNr;
    }

    public void setZcarProductionNr(int zcarProductionNr) {
        this.zcarProductionNr = zcarProductionNr;
    }

    public String getZcarAuftNr() {
        return zcarAuftNr;
    }

    public void setZcarAuftNr(String zcarAuftNr) {
        this.zcarAuftNr = zcarAuftNr;
    }

    public String getZcarDokSchluessl() {
        return zcarDokSchluessl;
    }

    public void setZcarDokSchluessl(String zcarDokSchluessl) {
        this.zcarDokSchluessl = zcarDokSchluessl;
    }

    public String getWerkId() {
        return werkId;
    }

    public void setWerkId(String werkId) {
        this.werkId = werkId;
    }

    public int getVbetNrZielland() {
        return vbetNrZielland;
    }

    public void setVbetNrZielland(int vbetNrZielland) {
        this.vbetNrZielland = vbetNrZielland;
    }

    public String getZcarDokFormat() {
        return zcarDokFormat;
    }

    public void setZcarDokFormat(String zcarDokFormat) {
        this.zcarDokFormat = zcarDokFormat;
    }

    public String getZcarZbllErstellt() {
        return zcarZbllErstellt;
    }

    public void setZcarZbllErstellt(String zcarZbllErstellt) {
        this.zcarZbllErstellt = zcarZbllErstellt;
    }

    public String getZcarNameEmfZbll() {
        return zcarNameEmfZbll;
    }

    public void setZcarNameEmfZbll(String zcarNameEmfZbll) {
        this.zcarNameEmfZbll = zcarNameEmfZbll;
    }

    public int getVbetNrEmpfZbll() {
        return vbetNrEmpfZbll;
    }

    public void setVbetNrEmpfZbll(int vbetNrEmpfZbll) {
        this.vbetNrEmpfZbll = vbetNrEmpfZbll;
    }

    public Date getZcarZtptErstellt() {
        return zcarZtptErstellt;
    }

    public void setZcarZtptErstellt(Date zcarZtptErstellt) {
        this.zcarZtptErstellt = zcarZtptErstellt;
    }

    public Date getZcarZtptDruck() {
        return zcarZtptDruck;
    }

    public void setZcarZtptDruck(Date zcarZtptDruck) {
        this.zcarZtptDruck = zcarZtptDruck;
    }

    public String getZcarDruckWerk() {
        return zcarDruckWerk;
    }

    public void setZcarDruckWerk(String zcarDruckWerk) {
        this.zcarDruckWerk = zcarDruckWerk;
    }

    public Date getZcarZtptVersand() {
        return zcarZtptVersand;
    }

    public void setZcarZtptVersand(Date zcarZtptVersand) {
        this.zcarZtptVersand = zcarZtptVersand;
    }

    public String getZcarWltpReqid() {
        return zcarWltpReqid;
    }

    public void setZcarWltpReqid(String zcarWltpReqid) {
        this.zcarWltpReqid = zcarWltpReqid;
    }

    @Override
    public Date getTechAenDatum() {
        return techAenDatum;
    }

    @Override
    public void setTechAenDatum(Date techAenDatum) {
        this.techAenDatum = techAenDatum;
    }

    @Override
    public String getTechAenUser() {
        return techAenUser;
    }

    @Override
    public void setTechAenUser(String techAenUser) {
        this.techAenUser = techAenUser;
    }

    @Override
    public Short getTechAenVersion() {
        return techAenVersion;
    }

    @Override
    public void setTechAenVersion(short techAenVersion) {
        this.techAenVersion = techAenVersion;
    }

    @Override
    public String toString() {
        return "CarBE [carPk=" + zcarPk + ", zcarProductionNr=" + zcarProductionNr + ", zcarAuftNr=" + zcarAuftNr
                + ", zcarDokSchluessl=" + zcarDokSchluessl + ", werkId=" + werkId + ", vbetNrZielland=" + vbetNrZielland
                + ", zcarDokFormat=" + zcarDokFormat + ", zcarZbllErstellt=" + zcarZbllErstellt + ", zcarNameEmfZbll="
                + zcarNameEmfZbll + ", vbetNrEmpfZbll=" + vbetNrEmpfZbll + ", zcarZtptErstellt=" + zcarZtptErstellt
                + ", zcarZtptDruck=" + zcarZtptDruck + ", zcarDruckWerk=" + zcarDruckWerk + ", zcarZtptVersand="
                + zcarZtptVersand + ", zcarWltpReqid=" + zcarWltpReqid + ", techAenDatum=" + techAenDatum
                + ", techAenUser=" + techAenUser + ", techAenVersion=" + techAenVersion + "]";
    }

}
