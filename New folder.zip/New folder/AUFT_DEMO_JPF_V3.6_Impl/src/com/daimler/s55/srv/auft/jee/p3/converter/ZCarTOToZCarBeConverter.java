package com.daimler.s55.srv.auft.jee.p3.converter;

import com.daimler.s55.srv.auft.jee.p3.entities.ZCarBE;
import com.daimler.s55.srv.auft.jee.p3.entities.ZCarPK;
import com.daimler.s55.srv.auft.jee.p3.services.types.to.ZCarTO;
import com.daimler.s55.srv.tequ.jee.p3.converter.api.Converter;

public class ZCarTOToZCarBeConverter implements Converter<ZCarTO, ZCarBE> {

    @Override
    public ZCarBE convert(ZCarTO s) {

        ZCarBE zcarBe = new ZCarBE();

        // ZCarPK zcarpk = new ZCarPK();

        zcarBe.setTechAenDatum(s.getTechAenDatum());
        zcarBe.setTechAenUser(s.getTechAenUser());
        zcarBe.setTechAenVersion(s.getTechAenVersion());
        zcarBe.setVbetNrEmpfZbll(s.getVbetNrEmpfZbll());
        zcarBe.setVbetNrZielland(s.getVbetNrZielland());
        zcarBe.setWerkId(s.getWerkId());
        zcarBe.setZcarAuftNr(s.getZcarAuftNr());
        zcarBe.setZcarDokFormat(s.getZcarDokFormat());
        zcarBe.setZcarDokSchluessl(s.getZcarDokSchluessl());
        zcarBe.setZcarDruckWerk(s.getZcarDruckWerk());
        zcarBe.setZcarNameEmfZbll(s.getZcarNameEmfZbll());
        zcarBe.setZcarProductionNr(s.getZcarProductionNr());
        zcarBe.setZcarWltpReqid(s.getZcarWltpReqid());
        zcarBe.setZcarZbllErstellt(s.getZcarZbllErstellt());
        zcarBe.setZcarZtptDruck(s.getZcarZtptDruck());
        zcarBe.setZcarZtptErstellt(s.getZcarZtptErstellt());
        zcarBe.setZcarZtptVersand(s.getZcarZtptVersand());

        // zcarpk.setZcarDokStuff(s.getZcarDokStuff());
        // zcarpk.setZcarDokVersion(s.getZcarDokVersion());
        // zcarpk.setZcarFahrgestNr(s.getZcarFahrgestNr());

        // zcarBe.setCarPk(zcarpk);
        zcarBe.setCarPk(new ZCarPK(s.getZcarFahrgestNr(), s.getZcarDokStuff(), s.getZcarDokVersion()));
        return zcarBe;
    }

}
