package com.daimler.s55.srv.auft.jee.p3.dao;

import java.util.List;

import com.daimler.s55.srv.auft.jee.p3.entities.ZCarBE;
import com.daimler.s55.srv.auft.jee.p3.entities.ZCarPK;

public interface ZCarDao {

    List<ZCarBE> getCarList();

    ZCarBE getCarByNumber(ZCarPK zcarPk);

}
