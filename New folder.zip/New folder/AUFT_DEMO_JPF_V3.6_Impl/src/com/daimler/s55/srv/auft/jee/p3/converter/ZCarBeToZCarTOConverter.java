package com.daimler.s55.srv.auft.jee.p3.converter;

import com.daimler.s55.srv.auft.jee.p3.entities.ZCarBE;
import com.daimler.s55.srv.auft.jee.p3.services.types.to.ZCarTO;
import com.daimler.s55.srv.tequ.jee.p3.converter.api.Converter;

public class ZCarBeToZCarTOConverter implements Converter<ZCarBE, ZCarTO> {

    @Override
    public ZCarTO convert(ZCarBE s) {

        ZCarTO zcarTo = new ZCarTO();

        zcarTo.setTechAenDatum(s.getTechAenDatum());
        zcarTo.setTechAenUser(s.getTechAenUser());
        zcarTo.setTechAenVersion(s.getTechAenVersion());
        zcarTo.setVbetNrEmpfZbll(s.getVbetNrEmpfZbll());
        zcarTo.setVbetNrZielland(s.getVbetNrZielland());
        zcarTo.setWerkId(s.getWerkId());
        zcarTo.setZcarAuftNr(s.getZcarAuftNr());
        zcarTo.setZcarDokFormat(s.getZcarDokFormat());
        zcarTo.setZcarDokSchluessl(s.getZcarDokSchluessl());
        zcarTo.setZcarDruckWerk(s.getZcarDruckWerk());
        zcarTo.setZcarNameEmfZbll(s.getZcarNameEmfZbll());
        zcarTo.setZcarProductionNr(s.getZcarProductionNr());
        zcarTo.setZcarWltpReqid(s.getZcarWltpReqid());
        zcarTo.setZcarZbllErstellt(s.getZcarZbllErstellt());
        zcarTo.setZcarZtptDruck(s.getZcarZtptDruck());
        zcarTo.setZcarZtptErstellt(s.getZcarZtptErstellt());
        zcarTo.setZcarZtptVersand(s.getZcarZtptVersand());
        zcarTo.setZcarFahrgestNr(s.getZCarPk().getZcarFahrgestNr());
        zcarTo.setZcarDokStuff(s.getZCarPk().getZcarDokStuff());
        zcarTo.setZcarDokVersion(s.getZCarPk().getZcarDokVersion());
        return zcarTo;
    }

}
