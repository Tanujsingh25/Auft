package com.daimler.s55.srv.auft.jee.p3.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.inject.Inject;

import com.daimler.s55.srv.auft.jee.p3.dao.ZCarDao;
import com.daimler.s55.srv.auft.jee.p3.entities.ZCarBE;
import com.daimler.s55.srv.auft.jee.p3.entities.ZCarPK;
import com.daimler.s55.srv.tequ.jee.p3.dao.api.AbstractDao;

public class ZCarDaoImpl extends AbstractDao<ZCarBE> implements ZCarDao {

    @Inject
    private Logger logger;

    @Override
    public List<ZCarBE> getCarList() {
        logger.warning("......................get all zcar dataList called from DAO..............");
        return findWithNamedQuery("ZCarEntity.fetchAllZcarData", ZCarBE.class);
    }

    @Override
    public ZCarBE getCarByNumber(ZCarPK zcarPk) {
        logger.warning("......................get zcar data by key called from DAO..............");
        Map<String, Object> param = new HashMap<>();
        param.put("zcarFahrgestNr", zcarPk.getZcarFahrgestNr());
        param.put("zcarDokStuff", zcarPk.getZcarDokStuff());
        param.put("zcarDokVersion", zcarPk.getZcarDokVersion());
        return findWithNamedQuerySingleResult("ZCarEntity.fetchCarByNumber", param, ZCarBE.class);
    }
}
