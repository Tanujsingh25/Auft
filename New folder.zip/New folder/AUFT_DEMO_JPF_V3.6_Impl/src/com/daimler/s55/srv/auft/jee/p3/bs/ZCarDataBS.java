package com.daimler.s55.srv.auft.jee.p3.bs;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.inject.Inject;

import com.daimler.s55.srv.auft.jee.p3.dao.ZCarDao;
import com.daimler.s55.srv.auft.jee.p3.entities.ZCarBE;
import com.daimler.s55.srv.auft.jee.p3.services.types.to.ZCarTO;
import com.daimler.s55.srv.tequ.jee.p3.converter.api.Converter;

public class ZCarDataBS {

    @Inject
    private ZCarDao zcarDao;

    @Inject
    private Logger logger;

    @Inject
    private Converter<ZCarBE, ZCarTO> converter;

    @Inject
    private Converter<ZCarTO, ZCarBE> beconverter;

    public List<ZCarTO> getAllZcarData() {
        logger.info("......................BS called get all zcar data..............");
        List<ZCarTO> zcarToList = new ArrayList<>();
        for (ZCarBE zcarBe : zcarDao.getCarList())
            zcarToList.add(converter.convert(zcarBe));
        return zcarToList;
    }

    public ZCarTO getZcarByFahtgestNrVersionAndStuff(ZCarTO zcarto) {
        logger.info("......................BS get zcar data by key called..............");
        ZCarBE zcarbe = beconverter.convert(zcarto);
        return converter.convert(zcarDao.getCarByNumber(zcarbe.getZCarPk()));
    }
}
