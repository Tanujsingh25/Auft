package com.daimler.s55.srv.auft.jee.p3.entities;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZCarPK {

    @Column(name = "ZCAR_FAHRGEST_NR", nullable = false, length = 17)
    private String zcarFahrgestNr;

    @Column(name = "ZCAR_DOK_STUFE", nullable = false, length = 1)
    private int zcarDokStuff;

    @Column(name = "ZCAR_DOK_VERSION", nullable = false)
    private int zcarDokVersion;

    public ZCarPK() {
    }

    public ZCarPK(String zcarFahrgestNr, int zcarDokStuff, int zcarDokVersion) {
        super();
        this.zcarFahrgestNr = zcarFahrgestNr;
        this.zcarDokStuff = zcarDokStuff;
        this.zcarDokVersion = zcarDokVersion;
    }

    public String getZcarFahrgestNr() {
        return zcarFahrgestNr;
    }

    public void setZcarFahrgestNr(String zcarFahrgestNr) {
        this.zcarFahrgestNr = zcarFahrgestNr;
    }

    public int getZcarDokStuff() {
        return zcarDokStuff;
    }

    public void setZcarDokStuff(int zcarDokStuff) {
        this.zcarDokStuff = zcarDokStuff;
    }

    public int getZcarDokVersion() {
        return zcarDokVersion;
    }

    public void setZcarDokVersion(int zcarDokVersion) {
        this.zcarDokVersion = zcarDokVersion;
    }

    @Override
    public int hashCode() {
        return Objects.hash(zcarDokStuff, zcarDokVersion, zcarFahrgestNr);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ZCarPK other = (ZCarPK) obj;
        return zcarDokStuff == other.zcarDokStuff && zcarDokVersion == other.zcarDokVersion
                && Objects.equals(zcarFahrgestNr, other.zcarFahrgestNr);
    }

    @Override
    public String toString() {
        return "CarPK [zcarFahrgestNr=" + zcarFahrgestNr + ", zcarDokStuff=" + zcarDokStuff + ", zcarDokVersion="
                + zcarDokVersion + "]";
    }

}
