package com.daimler.s55.srv.auft.jee.p3.restadapter.resource;

import java.util.List;
import java.util.logging.Logger;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.daimler.s55.srv.auft.jee.p3.restadapter.rest.types.ZCarRestTO;
import com.daimler.s55.srv.auft.jee.p3.services.ZCarInfoSI;
import com.daimler.s55.srv.auft.jee.p3.services.types.to.ZCarTO;
import com.daimler.s55.srv.tequ.jee.p3.converter.api.Converter;
import com.daimler.s55.srv.tequ.jee.p3.rest.api.Rest;

@Rest
@Path("/zcar")
public class ZcarResource {

    @Inject
    private ZCarInfoSI zcarSi;

    @Inject
    private Logger logger;

    @Inject
    private Converter<ZCarRestTO, ZCarTO> zcarRTOconverter;

    @GET
    @Path("/fetchallzcar")
    @Produces(MediaType.APPLICATION_JSON)
    public List<ZCarTO> getAllZcarData() {
        logger.info("Zcar resource called ..........");
        return zcarSi.getAllZcarData();
    }

    @GET
    @Path("/getZcar") // {FahtgestNr}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ZCarTO getZcarByFahtgestNrVersionAndStuff(ZCarRestTO zcarRto) {
        logger.info("Zcar resource called ..........");
        ZCarTO zcarto = zcarRTOconverter.convert(zcarRto);
        logger.info("primay key = " + zcarto.getZcarFahrgestNr() + " , " + zcarto.getZcarDokStuff() + " , "
                + zcarto.getZcarDokVersion());
        zcarSi.getZcarByFahtgestNrVersionAndStuff(zcarto);
        return zcarto;
        // Response.status(Status.CREATED).build();
    }

//    @GET
//    @Path("/test")
//    @Produces(MediaType.APPLICATION_JSON)
//    public String getAllZcarData() {
//        return "Hello";
//    }

}
