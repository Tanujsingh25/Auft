package com.daimler.s55.srv.auft.jee.p3.restadapter.rest.types;

import java.io.Serializable;

public class ZCarRestTO implements Serializable {
    private static final long serialVersionUID = 1;
    private String zcarFahrgestNr;
    private int zcarDokStuff;
    private int zcarDokVersion;

    public ZCarRestTO() {
    }

    public ZCarRestTO(String zcarFahrgestNr, int zcarDokStuff, int zcarDokVersion) {
        this.zcarFahrgestNr = zcarFahrgestNr;
        this.zcarDokStuff = zcarDokStuff;
        this.zcarDokVersion = zcarDokVersion;
    }

    public String getZcarFahrgestNr() {
        return this.zcarFahrgestNr;
    }

    public void setZcarFahrgestNr(String zcarFahrgestNr) {
        this.zcarFahrgestNr = zcarFahrgestNr;
    }

    public int getZcarDokStuff() {
        return this.zcarDokStuff;
    }

    public void setZcarDokStuff(int zcarDokStuff) {
        this.zcarDokStuff = zcarDokStuff;
    }

    public int getZcarDokVersion() {
        return this.zcarDokVersion;
    }

    public void setZcarDokVersion(int zcarDokVersion) {
        this.zcarDokVersion = zcarDokVersion;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ZCarRestTO [zcarFahrgestNr=");
        builder.append(zcarFahrgestNr);
        builder.append(", zcarDokStuff=");
        builder.append(zcarDokStuff);
        builder.append(", zcarDokVersion=");
        builder.append(zcarDokVersion);
        builder.append("]");
        return builder.toString();
    }
}