package com.daimler.s55.srv.auft.jee.p3.restadapter.application;

import javax.ws.rs.ApplicationPath;

import com.daimler.s55.srv.tequ.jee.p3.rest.api.RestApplication;

@ApplicationPath("/rest")
public class AuftDemoRestAdapter extends RestApplication {
}
