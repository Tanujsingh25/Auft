package com.daimler.s55.srv.auft.jee.p3.services;

import java.util.List;

import com.daimler.s55.srv.auft.jee.p3.services.types.to.ZCarTO;

/**
 * @author tanukuma
 *
 **/
public interface ZCarInfoSI {

    public List<ZCarTO> getAllZcarData();

    public ZCarTO getZcarByFahtgestNrVersionAndStuff(ZCarTO zcarTo);
}
