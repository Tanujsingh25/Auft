package com.daimler.s55.srv.auft.jee.p3.services.types.to;

import java.io.Serializable;
import java.util.Date;

public class ZCarTO implements Serializable {
    private static final long serialVersionUID = 1;
    private String zcarFahrgestNr;
    private int zcarDokStuff;
    private int zcarDokVersion;
    private int zcarProductionNr;
    private String zcarAuftNr;
    private String zcarDokSchluessl;
    private String werkId;
    private int vbetNrZielland;
    private String zcarDokFormat;
    private String zcarZbllErstellt;
    private String zcarNameEmfZbll;
    private int vbetNrEmpfZbll;
    private Date zcarZtptErstellt;
    private Date zcarZtptDruck;
    private String zcarDruckWerk;
    private Date zcarZtptVersand;
    private String zcarWltpReqid;
    private Date techAenDatum;
    private String techAenUser;
    private short techAenVersion;

    public ZCarTO() {
        super();
    }

    public ZCarTO(String zcarFahrgestNr, int zcarDokStuff, int zcarDokVersion) {
        this.zcarFahrgestNr = zcarFahrgestNr;
        this.zcarDokStuff = zcarDokStuff;
        this.zcarDokVersion = zcarDokVersion;
    }

    public ZCarTO(String zcarFahrgestNr, int zcarDokStuff, int zcarDokVersion, int zcarProductionNr, String zcarAuftNr,
            String zcarDokSchluessl, String werkId, int vbetNrZielland, String zcarDokFormat, String zcarZbllErstellt,
            String zcarNameEmfZbll, int vbetNrEmpfZbll, Date zcarZtptErstellt, Date zcarZtptDruck, String zcarDruckWerk,
            Date zcarZtptVersand, String zcarWltpReqid, Date techAenDatum, String techAenUser, short techAenVersion) {
        super();
        this.zcarFahrgestNr = zcarFahrgestNr;
        this.zcarDokStuff = zcarDokStuff;
        this.zcarDokVersion = zcarDokVersion;
        this.zcarProductionNr = zcarProductionNr;
        this.zcarAuftNr = zcarAuftNr;
        this.zcarDokSchluessl = zcarDokSchluessl;
        this.werkId = werkId;
        this.vbetNrZielland = vbetNrZielland;
        this.zcarDokFormat = zcarDokFormat;
        this.zcarZbllErstellt = zcarZbllErstellt;
        this.zcarNameEmfZbll = zcarNameEmfZbll;
        this.vbetNrEmpfZbll = vbetNrEmpfZbll;
        this.zcarZtptErstellt = zcarZtptErstellt;
        this.zcarZtptDruck = zcarZtptDruck;
        this.zcarDruckWerk = zcarDruckWerk;
        this.zcarZtptVersand = zcarZtptVersand;
        this.zcarWltpReqid = zcarWltpReqid;
        this.techAenDatum = techAenDatum;
        this.techAenUser = techAenUser;
        this.techAenVersion = techAenVersion;
    }

    public String getZcarFahrgestNr() {
        return this.zcarFahrgestNr;
    }

    public void setZcarFahrgestNr(String zcarFahrgestNr) {
        this.zcarFahrgestNr = zcarFahrgestNr;
    }

    public int getZcarDokStuff() {
        return this.zcarDokStuff;
    }

    public void setZcarDokStuff(int zcarDokStuff) {
        this.zcarDokStuff = zcarDokStuff;
    }

    public int getZcarDokVersion() {
        return this.zcarDokVersion;
    }

    public void setZcarDokVersion(int zcarDokVersion) {
        this.zcarDokVersion = zcarDokVersion;
    }

    public int getZcarProductionNr() {
        return this.zcarProductionNr;
    }

    public void setZcarProductionNr(int zcarProductionNr) {
        this.zcarProductionNr = zcarProductionNr;
    }

    public String getZcarAuftNr() {
        return this.zcarAuftNr;
    }

    public void setZcarAuftNr(String zcarAuftNr) {
        this.zcarAuftNr = zcarAuftNr;
    }

    public String getZcarDokSchluessl() {
        return this.zcarDokSchluessl;
    }

    public void setZcarDokSchluessl(String zcarDokSchluessl) {
        this.zcarDokSchluessl = zcarDokSchluessl;
    }

    public String getWerkId() {
        return this.werkId;
    }

    public void setWerkId(String werkId) {
        this.werkId = werkId;
    }

    public int getVbetNrZielland() {
        return this.vbetNrZielland;
    }

    public void setVbetNrZielland(int vbetNrZielland) {
        this.vbetNrZielland = vbetNrZielland;
    }

    public String getZcarDokFormat() {
        return this.zcarDokFormat;
    }

    public void setZcarDokFormat(String zcarDokFormat) {
        this.zcarDokFormat = zcarDokFormat;
    }

    public String getZcarZbllErstellt() {
        return this.zcarZbllErstellt;
    }

    public void setZcarZbllErstellt(String zcarZbllErstellt) {
        this.zcarZbllErstellt = zcarZbllErstellt;
    }

    public String getZcarNameEmfZbll() {
        return this.zcarNameEmfZbll;
    }

    public void setZcarNameEmfZbll(String zcarNameEmfZbll) {
        this.zcarNameEmfZbll = zcarNameEmfZbll;
    }

    public int getVbetNrEmpfZbll() {
        return this.vbetNrEmpfZbll;
    }

    public void setVbetNrEmpfZbll(int vbetNrEmpfZbll) {
        this.vbetNrEmpfZbll = vbetNrEmpfZbll;
    }

    public Date getZcarZtptErstellt() {
        return this.zcarZtptErstellt;
    }

    public void setZcarZtptErstellt(Date zcarZtptErstellt) {
        this.zcarZtptErstellt = zcarZtptErstellt;
    }

    public Date getZcarZtptDruck() {
        return this.zcarZtptDruck;
    }

    public void setZcarZtptDruck(Date zcarZtptDruck) {
        this.zcarZtptDruck = zcarZtptDruck;
    }

    public String getZcarDruckWerk() {
        return this.zcarDruckWerk;
    }

    public void setZcarDruckWerk(String zcarDruckWerk) {
        this.zcarDruckWerk = zcarDruckWerk;
    }

    public Date getZcarZtptVersand() {
        return this.zcarZtptVersand;
    }

    public void setZcarZtptVersand(Date zcarZtptVersand) {
        this.zcarZtptVersand = zcarZtptVersand;
    }

    public String getZcarWltpReqid() {
        return this.zcarWltpReqid;
    }

    public void setZcarWltpReqid(String zcarWltpReqid) {
        this.zcarWltpReqid = zcarWltpReqid;
    }

    public Date getTechAenDatum() {
        return this.techAenDatum;
    }

    public void setTechAenDatum(Date techAenDatum) {
        this.techAenDatum = techAenDatum;
    }

    public String getTechAenUser() {
        return this.techAenUser;
    }

    public void setTechAenUser(String techAenUser) {
        this.techAenUser = techAenUser;
    }

    public short getTechAenVersion() {
        return this.techAenVersion;
    }

    public void setTechAenVersion(short techAenVersion) {
        this.techAenVersion = techAenVersion;
    }

    @Override
    public String toString() {
        return "ZCarTO [zcarPk [ zcarFahrgestNr=" + zcarFahrgestNr + ", zcarDokStuff=" + zcarDokStuff
                + ", zcarDokVersion=" + zcarDokVersion + "], zcarProductionNr=" + zcarProductionNr + ", zcarAuftNr="
                + zcarAuftNr + ", zcarDokSchluessl=" + zcarDokSchluessl + ", werkId=" + werkId + ", vbetNrZielland="
                + vbetNrZielland + ", zcarDokFormat=" + zcarDokFormat + ", zcarZbllErstellt=" + zcarZbllErstellt
                + ", zcarNameEmfZbll=" + zcarNameEmfZbll + ", vbetNrEmpfZbll=" + vbetNrEmpfZbll + ", zcarZtptErstellt="
                + zcarZtptErstellt + ", zcarZtptDruck=" + zcarZtptDruck + ", zcarDruckWerk=" + zcarDruckWerk
                + ", zcarZtptVersand=" + zcarZtptVersand + ", zcarWltpReqid=" + zcarWltpReqid + ", techAenDatum="
                + techAenDatum + ", techAenUser=" + techAenUser + ", techAenVersion=" + techAenVersion + "]";
    }
}